def generate_response(prompt):
    return f"Réponse simulée de l’intelligence NetSecurePro IA : {prompt}"