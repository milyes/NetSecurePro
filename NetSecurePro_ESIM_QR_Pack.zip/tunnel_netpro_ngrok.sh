#!/bin/bash
echo "[🚀] Tunnel Ngrok vers 127.0.0.1:8081"
ngrok http 8081