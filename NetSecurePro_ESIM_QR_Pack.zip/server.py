from flask import Flask, jsonify, render_template_string, request
from ia_engine import generate_response

app = Flask(__name__)

html_page = """
<!DOCTYPE html>
<html lang="fr">
<head><meta charset="UTF-8"><title>Serveur IA NetSecurePro</title></head>
<body>
    <h1>🛡️ Serveur IA NetSecurePro</h1>
    <p>Statut : <strong>Actif</strong></p>
    <p>Route IA : <a href="/ia" target="_blank">/ia</a></p>
</body>
</html>
"""

@app.route('/')
def index():
    return render_template_string(html_page)

@app.route('/ia', methods=['POST'])
def ia():
    prompt = ""
    if request.is_json:
        prompt = request.json.get("message", "")
    else:
        prompt = request.form.get("message", "")
    response = generate_response(prompt)
    return jsonify({"response": response})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8081)