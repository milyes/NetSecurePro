import qrcode

esim_code = "LPA:1$esim-test.operator.com$ABCDE-12345"
img = qrcode.make(esim_code)
img.save("esim_code.png")
print("[✅] QR code eSIM généré : esim_code.png")
