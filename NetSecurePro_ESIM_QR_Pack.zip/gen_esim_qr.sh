#!/data/data/com.termux/files/usr/bin/bash

cd ~/bin/NetSecurePro_IA_Full || exit
echo "[⚙️] Génération du QR code eSIM..."
python3 generate_esim_qr.py
termux-open esim_code.png
