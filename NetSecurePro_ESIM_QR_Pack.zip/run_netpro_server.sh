#!/bin/bash
echo "[🔧] Démarrage du serveur Flask NetSecurePro..."
cd ~/bin/server || exit
nohup python3 server.py > server.log 2>&1 &
termux-open-url "http://127.0.0.1:8081"