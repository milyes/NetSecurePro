#!/bin/bash
echo "[🚀] Tunnel Cloudflare vers 127.0.0.1:8081"
cloudflared tunnel --url http://127.0.0.1:8081